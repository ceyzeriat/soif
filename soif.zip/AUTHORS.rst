Author:

- `Guillaume Schworer (Obs Meudon) <https://github.com/ceyzeriat>`_
