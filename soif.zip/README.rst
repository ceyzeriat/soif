.. soif
=======

.. image:: http://img.shields.io/travis/ceyzeriat/soif/master.svg?style=flat
    :target: https://travis-ci.org/ceyzeriat/soif
.. image:: https://coveralls.io/repos/github/ceyzeriat/soif/badge.svg?branch=master
    :target: https://coveralls.io/github/ceyzeriat/soif?branch=master
.. image:: http://img.shields.io/badge/license-GPLv3-blue.svg?style=flat
    :target: https://github.com/ceyzeriat/soif/blob/master/LICENSE

:Name: soif
:Website: https://github.com/ceyzeriat/soif
:Author: Guillaume Schworer
:Version: 1.0.2
